import SwiftUI

struct WeekValue: Identifiable {
    var id: Int
    var date : [Date]
}
