//
//  ContentView.swift
//  Test
//
//  Created by user247737 on 10/16/23.
//

import SwiftUI


let lightGray = Color(red: 0.8, green: 0.8, blue: 0.8)
let lighterGray = Color(red: 0.9, green: 0.9, blue: 0.9)
let bttnColor = Color(red: 0.8, green: 0.8, blue: 0.8)
let textColor = Color(red: 0, green: 0, blue: 0)
let white = Color(red: 1, green: 1, blue: 1)

struct ContentView: View {
    var body: some View {
        //ContentNavView()
        //MenuView()
        SignInUpView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


